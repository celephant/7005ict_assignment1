<?php $__env->startSection('title', 'Posts by ' . $author); ?>

<?php $__env->startSection('content'); ?>
    <h2>Posts by <?php echo e($author); ?></h2>
    <ul>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(url('/post/' . $post->id)); ?>"><?php echo e($post->title); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/7005ict/assingment/1/resources/views/userposts.blade.php ENDPATH**/ ?>