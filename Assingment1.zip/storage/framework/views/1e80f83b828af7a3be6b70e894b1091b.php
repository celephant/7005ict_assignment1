<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

    <div id="header">
        <h1>Home Page</h1>
    </div>
<br>
<br>

    <!-- Form to Create New Post -->
    <div id="create-post-section">
        <h2>Create a New Post</h2>
        <form action="<?php echo e(url('/create-post')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required><br>

            <label for="author">Author:</label>
            <input type="text" id="author" name="author" value="<?php echo e(Session::get('author')); ?>" required><br>

            <label for="message">Message:</label>
            <input id="message" name="message" required><br>

            <input type="submit" value="Create Post">
        </form>
    </div>

    <br>
    <br>
    <br>

    <!-- List of Posts -->
    <div id="list-posts-section">
    <h2>Posts</h2>
        <ul>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> 
                    
                    <a href="<?php echo e(url('/post/' .$post->id)); ?>"> <?php echo e($post->title); ?> </a>-<?php echo e($post->author); ?>@ <?php echo e((new DateTime($post->date))->format('d/m/Y H:i:s')); ?>

                    <br> --<?php echo e($post->like_count); ?> Likes <?php echo e($post->comments_count); ?> Comments
                    <br> <a href="<?php echo e(url('/edit/'.$post->id)); ?>"> Edit </a>
                    <form action="<?php echo e(url('/delete-post/' . $post->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Delete">
                    </form>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/7005ict/assingment/1/resources/views/home.blade.php ENDPATH**/ ?>