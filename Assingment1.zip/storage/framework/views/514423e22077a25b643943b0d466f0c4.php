<?php $__env->startSection('title','Edit Post'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Edit Post</h2>

    <form action="<?php echo e(url('/edit/' . $post->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="title">Upatae New Title:</label>
        <input type="text" id="title" name="title" required><br>


        <label for="message">Upatae New Message:</label>
        <input id="message" name="message" required><br>

        <input type="submit" value="Edit Post">
    </form>

    <h2>Original Post:</h2>
        <h3>Title:<?php echo e($post->title); ?></h3>
        <p>Message: <?php echo e($post->message); ?></p>
        <p>Author: <?php echo e($post->author); ?></p>
        <p>Date: <?php echo e($post->date); ?></p>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/7005ict/assingment/1/resources/views/editpost.blade.php ENDPATH**/ ?>