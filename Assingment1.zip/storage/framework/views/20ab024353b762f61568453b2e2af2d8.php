<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
<div id="post-details">
    <h2>Post</h2>

    <h3><?php echo e($post->title); ?></h3>

    <p>Author: <?php echo e($post->author); ?></p>
    <p>Date: <?php echo e($post->date); ?></p>
    <p>Message: <?php echo e($post->message); ?></p>
</div>

<div id="comments">
    <h2>Comments:</h2>
    <ul>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($comment->message); ?></a>
            <br> ---- <?php echo e($comment->author); ?> @ <?php echo e($comment->date); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

    <!-- New Comment Form -->
<div id="add-comment">
    <h2>Add a Comment</h2>
    <form action="<?php echo e(url('/post/' . $post->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="author">Author:</label>
        <input type="text" id="author" name="author" required><br>

        <label for="message">Message:</label>
        <input id="message" name="message" required></input><br>

        <input type="submit" value="Add Comment">
    </form>

    <!-- Like Post Form -->
    <h2>Like this Post</h2>
    <form action="<?php echo e(url('/post/' . $post->id . '/like')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="user_name">Your Name:</label>
        <input type="text" id="user_name" name="user_name" required>
        <input type="submit" value="Like">
    </form>
    <p>Total Likes: <?php echo e($post->like_count); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/7005ict/assingment/1/resources/views/postdetail.blade.php ENDPATH**/ ?>