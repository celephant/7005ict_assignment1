<?php $__env->startSection('title','User List'); ?>

<?php $__env->startSection('content'); ?>
<div id= "user list">
    <h2>User List</h2>
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(url('/userposts/' . $user->author)); ?>"><?php echo e($user->author); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/7005ict/assingment/1/resources/views/users.blade.php ENDPATH**/ ?>